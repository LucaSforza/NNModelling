from .runtime import InferenceModel, Model, load_model

__all__ = ['Model', 'load_model', 'InferenceModel']
